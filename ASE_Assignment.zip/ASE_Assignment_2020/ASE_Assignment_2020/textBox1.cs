﻿namespace ASE_Assignment_2020
{
    internal class textBox1
    {
    }
}